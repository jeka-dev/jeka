package core;

import base.Base;

public class Core extends Base {

    protected void getClassInfo() {
        System.out.println("Hello World from " + this.getClass().getSimpleName() + " -> " + getDate());
    }

}
