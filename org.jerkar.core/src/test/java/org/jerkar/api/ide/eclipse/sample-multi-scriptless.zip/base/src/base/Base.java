package base;

import java.util.Date;

public class Base {

    protected long getDate(){
        return new Date().getTime();
    }

}
