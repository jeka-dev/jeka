package desktop;

import core.Core;

public class Desktop extends Core {
    public static void main(String[] args) {
        Desktop desktop = new Desktop();
        desktop.getClassInfo();
    }
}
